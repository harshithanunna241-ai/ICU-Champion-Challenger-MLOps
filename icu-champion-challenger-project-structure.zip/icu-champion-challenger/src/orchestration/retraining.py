"""Retraining trigger policy. Drift alone should not imply model failure."""

def should_retrain(monitoring_summary, policy):
    raise NotImplementedError
