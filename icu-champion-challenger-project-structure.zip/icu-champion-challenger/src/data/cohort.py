"""Build patient-level ICU cohort with documented inclusion/exclusion rules."""

def build_cohort(admissions, icu_stays):
    # TODO: use version-pinned dataset mappings and reviewed cohort specification.
    raise NotImplementedError
