"""Extract approved research data. Implement against the approved database/access path."""

def extract_dataset():
    raise NotImplementedError("Implement secure, credentialed extraction; never bundle raw data.")
