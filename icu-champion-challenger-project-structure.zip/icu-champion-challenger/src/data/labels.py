"""Construct future-window outcome labels without leaking future data into features."""

def build_labels(prediction_times, event_table, horizon_hours=6):
    # TODO: define event timestamps, censoring, and competing-event rules.
    raise NotImplementedError
