"""Data quality checks for schemas, units, ranges, and timestamps."""

def validate_records(records):
    # TODO: validate required columns, dtypes, units, timestamps, and missingness.
    raise NotImplementedError
