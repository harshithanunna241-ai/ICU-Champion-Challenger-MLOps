"""Canonical feature schema shared by training and serving."""

FEATURE_COLUMNS = []
TARGET_COLUMN = "label"
