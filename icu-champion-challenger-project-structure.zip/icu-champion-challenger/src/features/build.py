"""Create point-in-time features from observations available at prediction time."""

def build_features(observations, prediction_times, lookback_hours=6):
    # TODO: aggregate reviewed vital/lab variables and missingness indicators.
    raise NotImplementedError
