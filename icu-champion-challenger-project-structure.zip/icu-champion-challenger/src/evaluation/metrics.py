"""Compute discrimination, threshold, and calibration metrics."""

def calculate_metrics(y_true, probabilities, threshold):
    raise NotImplementedError
