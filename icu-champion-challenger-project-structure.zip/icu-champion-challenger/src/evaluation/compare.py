"""Compare champion and challenger on the same frozen evaluation cohort."""

def compare_models(champion_predictions, challenger_predictions):
    raise NotImplementedError
