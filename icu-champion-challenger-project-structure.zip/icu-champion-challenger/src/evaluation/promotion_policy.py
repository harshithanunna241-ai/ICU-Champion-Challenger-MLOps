"""Apply versioned hard gates; do not auto-promote without approval."""

def evaluate_promotion(evaluation_report, policy):
    return {"status": "ELIGIBLE_FOR_REVIEW", "human_approval_required": True}
