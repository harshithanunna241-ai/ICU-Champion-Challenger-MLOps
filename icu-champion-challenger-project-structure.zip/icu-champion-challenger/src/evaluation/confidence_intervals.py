"""Patient-level bootstrap confidence intervals for evaluation metrics."""

def bootstrap_metric_ci(y_true, probabilities, patient_ids, metric_fn, n_bootstrap=1000):
    raise NotImplementedError
