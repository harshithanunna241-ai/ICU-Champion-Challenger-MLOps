"""Evaluate prespecified subgroups with sample-size/privacy safeguards."""

def evaluate_subgroups(frame, prediction_column, label_column, group_columns):
    raise NotImplementedError
