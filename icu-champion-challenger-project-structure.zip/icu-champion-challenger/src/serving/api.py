from fastapi import FastAPI
from src.serving.schemas import ResearchPredictionRequest, ResearchPredictionResponse
from datetime import datetime, timezone

app = FastAPI(title="ICU Deterioration Research API", version="0.1.0")

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/api/v1/predictions", response_model=ResearchPredictionResponse)
def predict(payload: ResearchPredictionRequest):
    # TODO: load approved model, validate schema, apply preprocessing, infer.
    # This placeholder is not a clinical model and intentionally does not infer.
    raise NotImplementedError("Connect a validated research model before enabling predictions.")
