from pydantic import BaseModel, Field

class ResearchPredictionRequest(BaseModel):
    # Replace with a versioned, validated feature schema.
    features: dict[str, float]

class ResearchPredictionResponse(BaseModel):
    risk_probability: float = Field(ge=0.0, le=1.0)
    model_version: str
    prediction_timestamp: str
    research_only: bool = True
