"""Train Random Forest challenger."""

def train(X_train, y_train):
    raise NotImplementedError
