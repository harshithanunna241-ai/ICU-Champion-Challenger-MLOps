"""Train regularized logistic regression baseline."""

def train(X_train, y_train):
    raise NotImplementedError
