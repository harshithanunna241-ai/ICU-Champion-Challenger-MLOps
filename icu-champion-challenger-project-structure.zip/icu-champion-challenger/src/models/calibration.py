"""Fit and assess probability calibration using validation data only."""

def calibrate_model(model, X_calibration, y_calibration):
    raise NotImplementedError
