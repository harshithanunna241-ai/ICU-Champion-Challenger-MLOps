# Frontend

Suggested React dashboard pages:
- Overview
- Dataset/cohort quality
- Experiments
- Model registry
- Champion–Challenger comparison
- Deployment and traffic routing
- Monitoring and alerts
- Retraining jobs
- Audit and governance

Use synthetic fixtures in local development. Display a persistent research-only notice.
