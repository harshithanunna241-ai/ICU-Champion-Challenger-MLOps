# Airflow DAGs

Suggested DAG tasks:
extract -> validate -> cohort -> labels -> features -> split -> train -> evaluate
-> register_candidate -> compare -> approval_wait -> shadow_deploy -> monitor

Do not place credentials in DAG source. Use the approved secrets backend.
