# ICU Patient Deterioration Prediction with Champion–Challenger MLOps

Research/education prototype. **Not for clinical use, diagnosis, triage, or treatment.**

## Quick start
1. Read `docs/PROJECT_OVERVIEW.md` and `docs/DATA_ACCESS.md`.
2. Complete the required PhysioNet credentialing, training, and data-use agreement before accessing MIMIC-IV/eICU.
3. Copy `.env.example` to `.env` and configure approved local services. Never commit `.env` or patient-level data.
4. Create an environment and install dependencies from `pyproject.toml`.
5. Implement the cohort, label, and feature pipelines before training models.

## Repository principles
- Keep raw clinical data outside Git and in access-controlled storage.
- Pin dataset release, cohort definition, label definition, feature schema, code commit, and evaluation policy for every run.
- Split by patient and time; prevent future-data leakage.
- A challenger is not promoted based on a single metric. Require calibration, subgroup, data-quality, operational, and approval gates.
- Use synthetic fixtures in public CI. Do not send credentialed clinical data to unapproved third-party services.

## Intended first model lineup
- Baseline: Logistic Regression
- Challengers: Random Forest and XGBoost (or LightGBM)
- Optional temporal challenger: GRU/LSTM after the tabular pipeline is stable

## Main workflow
`extract -> validate -> cohort/labels -> features -> split -> train -> track -> register -> compare -> approve -> shadow -> monitor -> promote/rollback`

See `docs/` for the project plan and implementation notes.
