Use notebooks for exploration only. Move production logic into src/. Do not commit sensitive patient-level extracts or outputs.
