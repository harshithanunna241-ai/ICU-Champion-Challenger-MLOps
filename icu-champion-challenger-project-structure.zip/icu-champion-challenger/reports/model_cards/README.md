Store model cards and evaluation reports here. Include intended use, exclusions, data lineage, metrics, calibration, subgroup results, limitations, and approval record.
