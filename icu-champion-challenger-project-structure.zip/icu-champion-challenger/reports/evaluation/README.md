Store generated comparison reports here. Do not commit reports containing patient-level information.
