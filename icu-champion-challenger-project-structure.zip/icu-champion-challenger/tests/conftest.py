import pytest

@pytest.fixture
def synthetic_sample():
    # Synthetic test fixture only; no patient data.
    return {"feature_a": 0.2, "feature_b": 1.1}
