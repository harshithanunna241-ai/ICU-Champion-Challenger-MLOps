from src.evaluation.promotion_policy import evaluate_promotion

def test_promotion_requires_human_review():
    result = evaluate_promotion({}, {})
    assert result["human_approval_required"] is True
