from pathlib import Path

def test_raw_data_directory_is_empty_in_repository():
    raw = Path("data/raw")
    assert not any(p.is_file() for p in raw.rglob("*"))
