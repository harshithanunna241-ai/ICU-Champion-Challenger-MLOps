# Project overview

## Research objective
Estimate the probability of a prespecified ICU deterioration event within a future prediction horizon using only information available at the prediction timestamp.

## Initial research specification (must be reviewed)
- Population: adult ICU stays, with cohort inclusion/exclusion rules documented.
- Look-back: candidate 6-hour window.
- Prediction horizon: candidate next 6 hours.
- Candidate composite outcome: new invasive ventilation, new vasopressor initiation, or death. Define event time and eligibility precisely with clinical input.
- Output: risk probability, prediction time, model version, and data-quality status.

This is a starting research definition, not a validated clinical endpoint. It must be reviewed before cohort construction.

## Key safeguards
- Point-in-time feature construction; no future information.
- Patient-level separation and temporal holdout.
- External validation only after harmonizing definitions and variables.
- Evaluate AUPRC, sensitivity, PPV, specificity, calibration, subgroup results, and uncertainty.
- Human approval before any model promotion.
- Research-only interface; no clinical actions.
