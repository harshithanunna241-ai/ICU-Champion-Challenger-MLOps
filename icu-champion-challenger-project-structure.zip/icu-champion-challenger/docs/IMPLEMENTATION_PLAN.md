# Implementation sequence

## Phase 0 — Scope
Freeze cohort, endpoint, event timestamps, look-back, horizon, exclusions, and intended research use.

## Phase 1 — Data access and inventory
Obtain approved access; inspect table schemas and dictionaries; record dataset release.

## Phase 2 — Cohort and labels
Build patient ICU stays and prediction timestamps. Handle censoring and post-event timestamps. Review label logic.

## Phase 3 — Features
Build point-in-time features and missingness indicators. Add automated leakage tests.

## Phase 4 — Baseline and challengers
Train Logistic Regression, Random Forest, and XGBoost/LightGBM. Tune only on training/validation data.

## Phase 5 — Reproducibility
Add DVC, MLflow, model artifacts, dataset/code/config metadata, and model cards.

## Phase 6 — Champion–Challenger
Implement comparison, confidence intervals, calibration, subgroup gates, policy versioning, and approval records.

## Phase 7 — Product layer
Build FastAPI, PostgreSQL metadata, and a dashboard.

## Phase 8 — Delivery and observability
Dockerize, add CI, deploy to a research staging environment, and add monitoring and rollback tests.

## Phase 9 — External validation
Harmonize eICU cohort and endpoint before using it as an external validation set.
