# Dataset access and handling

## Primary dataset: MIMIC-IV
MIMIC-IV is credentialed research data hosted by PhysioNet. Before access:
1. Create a PhysioNet account.
2. Complete the currently required human-subjects research training.
3. Apply for credentialed access.
4. Review and sign the dataset Data Use Agreement.
5. Access the exact dataset release permitted by the agreement.
6. Record release, extraction date, SQL/query version, and data provenance.

Official resources:
- https://mimic.mit.edu/docs/faq/how-to-get-access.html
- https://mimic.mit.edu/docs/iv/
- https://physionet.org/content/mimiciv/

## Secondary dataset: eICU-CRD
Consider eICU-CRD for external validation only after harmonizing cohort, outcome, timestamps, units, and feature definitions.
- https://eicu.mit.edu/gettingstarted/access/
- https://eicu.mit.edu/gettingstarted/dbsetup/

## Data security rules
- Do not commit raw, interim, or patient-level derived data.
- Keep data in approved access-controlled storage.
- Do not upload clinical data to public notebooks, issue trackers, or unapproved cloud services.
- Use synthetic fixtures for public CI and unit tests.
- Follow the dataset's DUA, citation, and redistribution terms.
