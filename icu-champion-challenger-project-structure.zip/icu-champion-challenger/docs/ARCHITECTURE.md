# Logical architecture

1. Data extraction: approved MIMIC-IV/eICU SQL extracts.
2. Validation: schema, units, ranges, missingness, timestamps, duplicates.
3. Cohort and labels: patient-stay cohort and future outcome window.
4. Features: point-in-time vital/lab summaries, trends, missingness indicators.
5. Training: baseline and challenger models.
6. Tracking/registry: MLflow experiments, artifacts, lineage.
7. Evaluation: paired comparison on a frozen cohort; confidence intervals, calibration, subgroup and operational gates.
8. Approval: human review and versioned policy.
9. Deployment: shadow first, controlled canary only in non-clinical research/demo setting.
10. Monitoring: data quality, drift, prediction distribution, delayed-label performance, latency and errors.
11. Recovery: retain prior approved model and test rollback.

A drift signal alone does not prove model performance has degraded. Outcome-based performance requires matured labels.
