# Kubernetes manifests

Add Deployment, Service, ConfigMap, Secret references, ServiceAccount, RBAC, NetworkPolicy,
resource requests/limits, readiness/liveness probes, and ingress here.

Never commit Secret values. Use an approved secrets manager. Start with a research namespace.
