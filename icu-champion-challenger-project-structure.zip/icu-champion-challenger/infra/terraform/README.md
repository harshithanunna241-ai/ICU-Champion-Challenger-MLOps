# Terraform

Optional infrastructure-as-code for an approved cloud research environment:
- private network and restricted subnets
- encrypted object storage
- managed database
- container registry and Kubernetes cluster
- IAM/RBAC and secrets integration
- logging and monitoring

Review dataset terms and institutional policy before selecting a cloud region or service.
